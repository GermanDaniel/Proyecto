package Proyecto;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.geom.Rectangle2D;
import java.util.Random;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingWorker;


public class clsPanel extends JPanel{
    
    private Dimension dimension         =       new Dimension(320,128);    
    private int maximo                     =       12;
    private int minimo                     =       1;
    private CuadradoNumero[] bNumber;
    private Color colorBg;
    
    // Constructor de clase   
    public clsPanel(){
        setSize(dimension);
        setVisible(true);                
    }
    
    @Override
    public void paintComponent(Graphics g){    
        Graphics2D g2 =(Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);    
        g2.setColor( new Color(0,255,125) );
        g2.fill(new Rectangle2D.Double(0,0,getWidth(),getHeight()));                 
        //pinta numeros y casillas
        if(bNumber!=null)
        for(CuadradoNumero b:bNumber){
            b.draw(g2);
        }
        
    }
    
    // Genera n numeros al azar y asigna a casillas
    // posiciona las casillas en el panel
    public void generar(int n){       
        bNumber = new CuadradoNumero[n];
        Random rn = new Random();
        
        for(int i=0;i<n;i++){
            bNumber[i] = new CuadradoNumero(); 
            bNumber[i].x= 10 + bNumber[i].WIDTH * i;
            bNumber[i].y = getHeight()/2 - bNumber[i].HEIGHT/2;
            int num = rn.nextInt(maximo - minimo + 1) + minimo;
            bNumber[i].setNumber(String.valueOf(num)); 
        }
        repaint();
    }
    
    
    // Comando para ordenar el array de numeros con el metodo de la burbuja
    public void ordenar(){
        try {
            
             if(bNumber!=null)           
                
            new BurbujaWorker().execute();//inicia worker
            
        } catch (Exception e) {
            
        }
       
    }
     
    
    // Clase 
    public class BurbujaWorker extends SwingWorker<Void, Void> {

        private int SPEED = 11; //velocidad de animacion (milisegundos)        
        
        @Override
        protected Void doInBackground() throws Exception {
            
         int i, j;
         CuadradoNumero aux;
         for(i=0;i<bNumber.length-1;i++)
            for(j=0;j<bNumber.length-i-1;j++)
                if(bNumber[j+1].getValue()<bNumber[j].getValue()){
                      aux=bNumber[j+1];
                     
                      //animar movimiento
                      girar(j,j+1);                      
                      bNumber[j+1]=bNumber[j];
                      bNumber[j]=aux;
                   }         
            JOptionPane.showMessageDialog(null, "Se ordeno correctamente", "ORDENADO", JOptionPane.QUESTION_MESSAGE);
            return null;
        }
        

        private void girar(int a , int b){
            //movimiento vertical
            for(int i=0; i< bNumber[0].HEIGHT;i++){
                bNumber[a].y = bNumber[a].y - 1;
                bNumber[b].y = bNumber[b].y + 1;                   
                try {
                    Thread.sleep(SPEED);
                 } catch (InterruptedException e) {}
                repaint();
            }
            
            //movimiento horizontal
            for(int i=0; i< bNumber[0].WIDTH;i++){
                 bNumber[a].x = bNumber[a].x + 1;
                 bNumber[b].x = bNumber[b].x - 1;
                 try {
                    Thread.sleep(SPEED);
                 } catch (InterruptedException e) {}
                repaint();
            }
            
            //movimiento vertical
            for(int i=0; i< bNumber[0].HEIGHT;i++){
                bNumber[a].y = bNumber[a].y + 1;
                bNumber[b].y = bNumber[b].y - 1;                   
                try {
                    Thread.sleep(SPEED);
                 } catch (InterruptedException e) {}
                repaint();
            }
        }
        
    }
    
}
